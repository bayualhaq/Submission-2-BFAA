package com.bayu.submission1

data class User(
    val login: String,
    val avatar_url: String
)