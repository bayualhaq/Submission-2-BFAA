package com.bayu.submission1

data class UserResponse(
    val items: ArrayList<User>
)